To run the installer:
1. If you don't already have the installer, download all files in this folder to your computer.
2. Double click on TrustInstaller.exe.
3. Follow the instructions in the installer to update to the latest version of Trust.
