To run the installer:

1. If you don't already have the installer, download [TrustInstaller.zip](https://github.com/cyritegamestudios/trust/blob/main/Setup/TrustInstaller.zip) and unzip it to your Desktop.
2. Double-click on TrustInstaller.exe.
3. Follow the instructions in the installer to update to the latest version of Trust.
4. To check for updates, launch the Trust installer.

**NOTE: the installer *CANNOT* be located inside of your Trust folder or updates won't be installed properly. Move the installer to your Desktop folder or elsewhere outside of the Trust folder.**
